class ToolSourceOperationalParticipationValidationError(ValueError):
    pass
