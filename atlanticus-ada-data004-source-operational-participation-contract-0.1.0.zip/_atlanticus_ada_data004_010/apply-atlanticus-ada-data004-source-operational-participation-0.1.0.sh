#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${1:-.}"
ROOT="$(cd "$ROOT" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
CONSUMPTION_REL="scopes/ada/web/configuration/tool-source-consumption"
CONSUMPTION="$ROOT/$CONSUMPTION_REL"
PARTICIPATION_REL="scopes/ada/web/configuration/tool-source-operational-participation"
PARTICIPATION="$ROOT/$PARTICIPATION_REL"
APP_REL="scopes/ada/web/application/ada-generic-application"
APP="$ROOT/$APP_REL"
TIME_PREVIEW_REL="scopes/ada/web/time-status/preview"
CONTENT_PREVIEW_REL="scopes/ada/web/content-state/preview"
INSPECTION_PREVIEW_REL="scopes/ada/web/inspection/preview"
SUCCESS=0

fail() {
    printf '%s\n' "$*" >&2
    exit 1
}

rollback() {
    local status=$?
    if [[ "$SUCCESS" -eq 1 ]]; then
        return
    fi
    set +e
    printf '%s\n' "DATA-004 installer failed; removing incomplete increment." >&2
    rm -rf "$PARTICIPATION"
    exit "$status"
}
trap rollback EXIT

command -v uv >/dev/null 2>&1 || fail "UV is required"
[[ -d "$CONSUMPTION" ]] || fail "DATA-003 Tool Source Consumption package is missing"
[[ -d "$APP" ]] || fail "Generic Application project is missing"
[[ ! -e "$PARTICIPATION" ]] || fail "DATA-004 package already exists: $PARTICIPATION_REL"
[[ ! -e "$ROOT/$TIME_PREVIEW_REL" ]] || fail "Time Status preview must already be retired"
[[ ! -e "$ROOT/$CONTENT_PREVIEW_REL" ]] || fail "Content State preview must already be retired"
[[ -d "$ROOT/$INSPECTION_PREVIEW_REL" ]] || fail "KPI Inspection preview must remain present"

printf '%s\n' "[1/6] Validating DATA-003 authoritative pre-state"
uv run --python 3.14.2 --no-project python - "$ROOT" <<'PY'
import ast
import sys
import tomllib
from pathlib import Path

root = Path(sys.argv[1])
consumption = root / 'scopes/ada/web/configuration/tool-source-consumption'
application = root / 'scopes/ada/web/application/ada-generic-application'

with (consumption / 'pyproject.toml').open('rb') as stream:
    consumption_project = tomllib.load(stream)['project']
if consumption_project['name'] != 'ada-configuration-tool-source-consumption':
    raise SystemExit('Unexpected DATA-003 package identity')
if consumption_project['version'] != '0.1.0':
    raise SystemExit('Expected Tool Source Consumption 0.1.0')

with (application / 'pyproject.toml').open('rb') as stream:
    application_project = tomllib.load(stream)['project']
if application_project['version'] != '0.1.32':
    raise SystemExit('Expected Generic Application 0.1.32')
if 'ada-configuration-tool-source-consumption==0.1.0' not in application_project['dependencies']:
    raise SystemExit('Generic Application is not consuming DATA-003')

models = consumption / 'src/ada/configuration/tool_source_consumption/models.py'
tree = ast.parse(models.read_text())
contract = next(
    node
    for node in tree.body
    if isinstance(node, ast.ClassDef) and node.name == 'ToolSourceConsumption'
)
fields = [
    node.target.id
    for node in contract.body
    if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name)
]
if fields != ['tool_key', 'source_keys']:
    raise SystemExit('Unexpected DATA-003 membership contract shape')
PY

printf '%s\n' "[2/6] Applying Source Operational Participation contract"
mkdir -p "$ROOT/scopes/ada/web/configuration"
cp -R "$PAYLOAD/$PARTICIPATION_REL" "$ROOT/scopes/ada/web/configuration/"

printf '%s\n' "[3/6] Generating and synchronizing DATA-004 lock with UV"
(
    cd "$PARTICIPATION"
    uv lock --python 3.14.2
    uv sync --locked --python 3.14.2 --all-groups
)

printf '%s\n' "[4/6] Running Source Operational Participation gate"
(
    cd "$PARTICIPATION"
    uv run --python 3.14.2 ruff check src tests
    uv run --python 3.14.2 ruff format --check src tests
    uv run --python 3.14.2 pytest
)

printf '%s\n' "[5/6] Validating mirrors and DATA-004 contract boundaries"
uv run --python 3.14.2 --no-project python - "$ROOT" <<'PY'
import ast
import sys
from pathlib import Path

root = Path(sys.argv[1])
base = root / 'scopes/ada/web/configuration/tool-source-operational-participation'
pairs = (
    ('errors.py', 'errors.py'),
    ('models.py', 'models.py'),
    ('contracts.py', 'contracts.py'),
    ('__init__.py', '__init__.py'),
)
for productive_name, commented_name in pairs:
    productive = (
        base
        / 'src/ada/configuration/tool_source_operational_participation'
        / productive_name
    )
    commented = (
        base
        / 'commented/ada/configuration/tool_source_operational_participation'
        / commented_name
    )
    productive_ast = ast.dump(ast.parse(productive.read_text()), include_attributes=False)
    commented_ast = ast.dump(ast.parse(commented.read_text()), include_attributes=False)
    if productive_ast != commented_ast:
        raise SystemExit(f'Commented mirror differs semantically: {productive_name}')

models = (
    base
    / 'src/ada/configuration/tool_source_operational_participation/models.py'
).read_text().casefold()
contracts = (
    base
    / 'src/ada/configuration/tool_source_operational_participation/contracts.py'
).read_text().casefold()
for forbidden in (
    'endpoint',
    'query',
    'callback',
    'renderer',
    'cosmos',
    'sharepoint',
    'show_in_summary',
    'show_in_popover',
    'affects_overlay',
):
    if forbidden in models or forbidden in contracts:
        raise SystemExit(f'Forbidden implementation/UI semantic found: {forbidden}')
for forbidden_source in ("'pi'", '"pi"', "'dispatch'", '"dispatch"', "'blockgrade'", '"blockgrade"'):
    if forbidden_source in models or forbidden_source in contracts:
        raise SystemExit(f'Hardcoded source catalog entry found: {forbidden_source}')
print('DATA-004 mirrors and contract boundaries validated')
PY

printf '%s\n' "[6/6] Compiling and verifying final contract"
uv run --python 3.14.2 --no-project python -m compileall -q \
    "$PARTICIPATION/src" \
    "$PARTICIPATION/tests" \
    "$PARTICIPATION/commented"
uv run --python 3.14.2 --no-project python - "$PARTICIPATION" <<'PY'
import sys
import tomllib
from pathlib import Path

package = Path(sys.argv[1])
with (package / 'pyproject.toml').open('rb') as stream:
    project = tomllib.load(stream)['project']
if project['name'] != 'ada-configuration-tool-source-operational-participation':
    raise SystemExit('Unexpected DATA-004 package identity')
if project['version'] != '0.1.0':
    raise SystemExit('Unexpected DATA-004 package version')
PY

SUCCESS=1
trap - EXIT
printf '%s\n' "DATA-004 contract increment applied and validated:"
printf '%s\n' "Source Operational Participation 0.1.0"
printf '%s\n' "CONTROL carries pre-degrading/degrading thresholds."
printf '%s\n' "Effective OBSERVATION is CONTROL plus ADDITIONAL OBSERVATION."
printf '%s\n' "All participation sources must already belong to DATA-003 consumption."
printf '%s\n' "No named source catalog or implementation/UI details are stored here."
