class AlarmManagementSummaryDefinitionError(ValueError):
    pass
