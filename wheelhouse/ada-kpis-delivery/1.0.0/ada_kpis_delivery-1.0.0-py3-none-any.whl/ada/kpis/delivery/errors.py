class KpiDeliveryValidationError(ValueError):
    pass
