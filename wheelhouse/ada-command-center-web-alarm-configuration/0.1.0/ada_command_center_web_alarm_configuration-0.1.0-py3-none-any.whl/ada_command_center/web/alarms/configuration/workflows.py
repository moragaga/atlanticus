from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

from ada_command_center.domain.alarms import (
    AlarmConfiguration,
    AlarmConfigurationSnapshot,
    AlarmConfigurationValidationError,
)
from ada_command_center.web.alarms.configuration.errors import (
    AlarmConfigurationSourceError,
    AlarmConfigurationToolDependencyError,
)
from ada_command_center.web.alarms.configuration.source_release import (
    AlarmConfigurationSourceService,
)
from ada_command_center.web.alarms.configuration.tool_dependencies import (
    pin_workspace_tool_catalog_revision,
    require_workspace_tool_catalog_revision,
    select_alarm_tool_dependencies,
)
from ada_command_center.web.alarms.configuration.tool_references import AlarmToolReferenceCatalog
from atlanticus.web.manager.projection import (
    DraftValidationResult,
    ProjectionAuditRecord,
    ProjectionIssue,
    ProjectionSummaryItem,
)
from atlanticus.web.manager.source import (
    SourceHistoryReadResult,
    SourcePublicationResult,
    SourceReadResult,
)
from atlanticus.web.manager.workspace import build_workspace_revision
from atlanticus.web.source.models import HistoryPage, SourceKey, SourceReleaseRef, SourceSnapshot

AlarmConfigurationAuditActorProvider = Callable[[], str]
AlarmToolReferenceProvider = Callable[[], AlarmToolReferenceCatalog | None]


class AlarmConfigurationManagerSourceWorkflow:
    def __init__(
        self,
        *,
        source: AlarmConfigurationSourceService,
        audit_actor_provider: AlarmConfigurationAuditActorProvider,
        tool_reference_provider: AlarmToolReferenceProvider,
    ) -> None:
        self._source = source
        self._audit_actor_provider = audit_actor_provider
        self._tool_reference_provider = tool_reference_provider

    @property
    def source_key(self) -> SourceKey:
        return self._source.source_key

    def get_source_snapshot(self) -> SourceSnapshot:
        return self._source.get_current()

    def load_current_source(self) -> SourceReadResult:
        snapshot = self._source.get_current()
        if snapshot.current is None:
            return SourceReadResult(snapshot=snapshot, payload=None)
        release = self._source.load_release(snapshot.current.release_ref)
        refreshed = self._source.get_current()
        if refreshed.current != snapshot.current:
            raise AlarmConfigurationSourceError(
                'Alarm Configuration source changed while it was being loaded'
            )
        payload = release.snapshot.configuration.to_document()
        tool_references = self._tool_reference_provider()
        if tool_references is not None:
            payload = pin_workspace_tool_catalog_revision(
                payload,
                tool_references.catalog_revision,
            )
        return SourceReadResult(
            snapshot=refreshed,
            payload=payload,
        )

    def list_history(self, *, limit: int = 20) -> HistoryPage:
        return self._source.query_history(page_size=limit)

    def load_history_release(
        self,
        release_ref: SourceReleaseRef,
    ) -> SourceHistoryReadResult:
        release = self._source.load_release(release_ref)
        return SourceHistoryReadResult(
            release_ref=release.release_ref,
            payload=release.snapshot.configuration.to_document(),
        )

    def publish_draft(
        self,
        payload: dict[str, object],
        expected_source_snapshot: SourceSnapshot,
    ) -> SourcePublicationResult:
        if expected_source_snapshot.source_key != self._source.source_key:
            raise AlarmConfigurationSourceError(
                'Alarm Configuration source snapshot uses a different source key'
            )
        current = self._source.get_current()
        if current.current != expected_source_snapshot.current:
            raise AlarmConfigurationSourceError(
                'Alarm Configuration source changed before publication'
            )
        actor = self._audit_actor_provider().strip()
        if not actor:
            raise AlarmConfigurationSourceError(
                'Alarm Configuration publication actor must not be empty'
            )
        configuration = AlarmConfiguration.from_document(dict(payload))
        try:
            expected_tool_revision = require_workspace_tool_catalog_revision(payload)
        except AlarmConfigurationToolDependencyError as error:
            raise AlarmConfigurationSourceError(str(error)) from error
        tool_references = self._tool_reference_provider()
        if tool_references is None:
            raise AlarmConfigurationSourceError(
                'Confirmed Tool Catalog is required for Alarm Configuration publication'
            )
        if tool_references.catalog_revision != expected_tool_revision:
            raise AlarmConfigurationSourceError(
                'Confirmed Tool Catalog changed after Alarm Configuration validation'
            )
        try:
            tool_dependencies = select_alarm_tool_dependencies(
                configuration,
                tool_references.dependencies,
            )
        except AlarmConfigurationToolDependencyError as error:
            raise AlarmConfigurationSourceError(str(error)) from error
        alarm_snapshot = AlarmConfigurationSnapshot(
            configuration=configuration,
            tool_dependencies=tool_dependencies,
        )
        basis_release = current.current.release_ref if current.current is not None else None
        published = self._source.publish_snapshot(
            alarm_snapshot,
            published_by=actor,
            expected_concurrency_token=current.concurrency_token,
            basis_release=basis_release,
        )
        return SourcePublicationResult(
            source=published,
            audit=ProjectionAuditRecord(
                actor=actor,
                occurred_at=published.release.release_ref.published_at_utc,
            ),
            summary=_summary(configuration),
        )


class AlarmConfigurationManagerDraftValidationWorkflow:
    def __init__(
        self,
        *,
        audit_actor_provider: AlarmConfigurationAuditActorProvider,
        tool_reference_provider: AlarmToolReferenceProvider,
    ) -> None:
        self._audit_actor_provider = audit_actor_provider
        self._tool_reference_provider = tool_reference_provider

    def validate_draft(self, payload: dict[str, object]) -> DraftValidationResult:
        audit = ProjectionAuditRecord(
            actor=self._audit_actor_provider().strip(),
            occurred_at=datetime.now(UTC),
        )
        revision = build_workspace_revision(payload)
        try:
            configuration = AlarmConfiguration.from_document(dict(payload))
        except AlarmConfigurationValidationError as error:
            return _invalid_validation(
                revision=revision,
                audit=audit,
                code='alarm.configuration.invalid',
                message=str(error),
            )
        try:
            expected_tool_revision = require_workspace_tool_catalog_revision(payload)
        except AlarmConfigurationToolDependencyError as error:
            return _invalid_validation(
                revision=revision,
                audit=audit,
                code='alarm.tools.catalog_revision_missing',
                message=str(error),
            )
        tool_references = self._tool_reference_provider()
        if tool_references is None:
            return _invalid_validation(
                revision=revision,
                audit=audit,
                code='alarm.tools.catalog_unavailable',
                message='Confirmed Tool Catalog is not available',
            )
        if tool_references.catalog_revision != expected_tool_revision:
            return _invalid_validation(
                revision=revision,
                audit=audit,
                code='alarm.tools.catalog_changed',
                message='Confirmed Tool Catalog changed after the draft was saved',
            )
        try:
            select_alarm_tool_dependencies(
                configuration,
                tool_references.dependencies,
            )
        except AlarmConfigurationToolDependencyError as error:
            return _invalid_validation(
                revision=revision,
                audit=audit,
                code='alarm.tools.reference_not_found',
                message=str(error),
            )
        return DraftValidationResult(
            draft_revision=revision,
            valid=True,
            audit=audit,
            summary=_summary(configuration),
        )


def _invalid_validation(
    *,
    revision: str,
    audit: ProjectionAuditRecord,
    code: str,
    message: str,
) -> DraftValidationResult:
    return DraftValidationResult(
        draft_revision=revision,
        valid=False,
        audit=audit,
        issues=(ProjectionIssue(code=code, message=message),),
    )


def _summary(
    configuration: AlarmConfiguration,
) -> tuple[ProjectionSummaryItem, ...]:
    return (
        ProjectionSummaryItem('Rules', str(len(configuration.rules))),
        ProjectionSummaryItem(
            'Active rules',
            str(sum(rule.is_active for rule in configuration.rules)),
        ),
        ProjectionSummaryItem('Messages', str(len(configuration.messages))),
    )
