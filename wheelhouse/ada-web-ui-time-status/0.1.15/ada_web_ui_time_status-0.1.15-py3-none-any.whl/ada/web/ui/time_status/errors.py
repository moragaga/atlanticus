class TimeStatusDefinitionError(ValueError):
    pass
