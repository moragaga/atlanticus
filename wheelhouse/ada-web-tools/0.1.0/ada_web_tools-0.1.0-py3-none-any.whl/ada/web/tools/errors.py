class ToolConfigurationValidationError(ValueError):
    pass
