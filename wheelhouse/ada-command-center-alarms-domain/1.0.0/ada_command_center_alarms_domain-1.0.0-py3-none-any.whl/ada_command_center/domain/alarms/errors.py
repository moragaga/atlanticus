class AlarmConfigurationValidationError(ValueError):
    pass
