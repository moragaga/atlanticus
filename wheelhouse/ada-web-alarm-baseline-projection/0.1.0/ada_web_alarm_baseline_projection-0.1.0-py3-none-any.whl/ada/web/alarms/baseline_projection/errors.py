class AlarmBaselineProjectionError(ValueError):
    pass
