from __future__ import annotations

from atlanticus.integrations.pi.contracts import PiCatalog, PiWebApiSource
from atlanticus.operational_data.processes.pi.catalog.definitions import DEFINITIONS, SOURCE
from atlanticus.operational_data.processes.pi.errors import PiWebApiCatalogError


def build_catalog() -> PiCatalog:
    if not isinstance(SOURCE, PiWebApiSource):
        raise PiWebApiCatalogError('PI Web API catalog source must be PiWebApiSource')
    if SOURCE.interpolation_seconds is None:
        raise PiWebApiCatalogError('PI Web API catalog must define interpolation_seconds')
    if not isinstance(DEFINITIONS, tuple):
        raise PiWebApiCatalogError('PI Web API catalog definitions must be a tuple')
    try:
        catalog = PiCatalog(source=SOURCE, definitions=DEFINITIONS)
    except (TypeError, ValueError) as error:
        raise PiWebApiCatalogError(str(error)) from error
    if not any(item.is_active for item in catalog.definitions):
        raise PiWebApiCatalogError('PI Web API catalog must contain active definitions')
    return catalog
