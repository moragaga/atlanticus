"""Ejecución controlada y coordinación de jobs backend Atlanticus."""

from atlanticus.runtime.configuration import RuntimeConfiguration
from atlanticus.runtime.context import JobRuntimeContext
from atlanticus.runtime.definition import JobDefinition
from atlanticus.runtime.errors import (
    AtlanticusRuntimeError,
    ConcurrentExecutionError,
    LeaseOwnershipLostError,
    LeaseRenewalError,
    RuntimeCancellationRequested,
    RuntimeConfigurationError,
    RuntimeContractError,
)
from atlanticus.runtime.runner import RuntimeExecutionResult, execute_job

__version__ = '1.0.0'

__all__ = [
    'AtlanticusRuntimeError',
    'ConcurrentExecutionError',
    'JobDefinition',
    'JobRuntimeContext',
    'LeaseOwnershipLostError',
    'LeaseRenewalError',
    'RuntimeCancellationRequested',
    'RuntimeConfiguration',
    'RuntimeConfigurationError',
    'RuntimeContractError',
    'RuntimeExecutionResult',
    '__version__',
    'execute_job',
]
