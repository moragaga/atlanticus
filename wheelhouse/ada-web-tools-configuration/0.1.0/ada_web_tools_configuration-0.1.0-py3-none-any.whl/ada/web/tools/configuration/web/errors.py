class ToolSourceEditorValidationError(ValueError):
    pass
