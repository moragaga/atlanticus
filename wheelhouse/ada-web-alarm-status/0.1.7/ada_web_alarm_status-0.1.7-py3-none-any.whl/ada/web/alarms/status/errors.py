class AlarmStatusDefinitionError(ValueError):
    pass
