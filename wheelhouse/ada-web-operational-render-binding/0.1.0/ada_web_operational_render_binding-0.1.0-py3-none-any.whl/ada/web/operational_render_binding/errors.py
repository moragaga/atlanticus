class OperationalRenderBindingError(ValueError):
    pass
