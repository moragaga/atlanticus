class ToolDependencyManifestValidationError(ValueError):
    pass
