from __future__ import annotations

from ada.web.kpis.registry.models import KpiRegistry
from ada.web.kpis.definition.coverage import (
    KpiDefinitionCatalog,
    build_kpi_definition_coverage,
    validate_kpi_definition_configuration,
)
from ada.web.kpis.definition.errors import KpiDefinitionValidationError
from ada.web.kpis.definition.configuration.errors import KpiDefinitionProjectionError
from ada.web.kpis.definition.configuration.source_release import KpiDefinitionSourceCodec
from atlanticus.web.projection.models import ProjectionTarget
from atlanticus.web.projection.service import ProjectionBuilder, SourceProjectionService
from atlanticus.web.projection.store import ProjectionStore
from atlanticus.web.source.models import SourceKey, SourceReleaseMetadata, SourceResource
from atlanticus.web.source.store import SourceStore


class KpiDefinitionProjectionBuilder(ProjectionBuilder[KpiDefinitionCatalog]):
    def __init__(
        self,
        *,
        kpi_registry_projection: ProjectionStore[KpiRegistry],
        kpi_registry_source_key: SourceKey,
        codec: KpiDefinitionSourceCodec | None = None,
    ) -> None:
        self._kpi_registry_projection = kpi_registry_projection
        self._kpi_registry_source_key = kpi_registry_source_key
        self._codec = codec or KpiDefinitionSourceCodec()

    def build(
        self,
        *,
        target: ProjectionTarget,
        release: SourceReleaseMetadata,
        resources: tuple[SourceResource, ...],
    ) -> KpiDefinitionCatalog:
        del release
        dependency = _require_kpi_registry_dependency(
            target,
            self._kpi_registry_source_key,
        )
        projection = self._kpi_registry_projection.get_active(
            self._kpi_registry_source_key
        )
        if projection is None:
            raise KpiDefinitionProjectionError('KPI Registry projection is not available')
        if projection.target != dependency:
            raise KpiDefinitionProjectionError(
                'KPI Registry projection changed before KPI Definition projection'
            )
        if not isinstance(projection.payload, KpiRegistry):
            raise KpiDefinitionProjectionError('KPI Registry projection payload is invalid')
        configuration = self._codec.decode(resources).configuration
        try:
            validate_kpi_definition_configuration(configuration, projection.payload)
        except KpiDefinitionValidationError as error:
            raise KpiDefinitionProjectionError(
                'Published KPI Definition is not valid for projection'
            ) from error
        return KpiDefinitionCatalog(
            configuration=configuration,
            coverage=build_kpi_definition_coverage(configuration, projection.payload),
        )


def create_kpi_definition_projection_service(
    *,
    source: SourceStore,
    projection: ProjectionStore[KpiDefinitionCatalog],
    kpi_registry_projection: ProjectionStore[KpiRegistry],
    kpi_registry_source_key: SourceKey,
) -> SourceProjectionService[KpiDefinitionCatalog]:
    def select_dependencies(_source_key: SourceKey) -> tuple[ProjectionTarget, ...]:
        dependency = kpi_registry_projection.get_active(kpi_registry_source_key)
        if dependency is None:
            raise KpiDefinitionProjectionError('KPI Registry projection is not available')
        if not isinstance(dependency.payload, KpiRegistry):
            raise KpiDefinitionProjectionError('KPI Registry projection payload is invalid')
        return (dependency.target,)

    return SourceProjectionService(
        source=source,
        projection=projection,
        builder=KpiDefinitionProjectionBuilder(
            kpi_registry_projection=kpi_registry_projection,
            kpi_registry_source_key=kpi_registry_source_key,
        ),
        dependency_selector=select_dependencies,
    )


def _require_kpi_registry_dependency(
    target: ProjectionTarget,
    kpi_registry_source_key: SourceKey,
) -> ProjectionTarget:
    if len(target.dependencies) != 1:
        raise KpiDefinitionProjectionError(
            'KPI Definition projection target must contain exactly one KPI Registry dependency'
        )
    dependency = target.dependencies[0]
    if dependency.source_key != kpi_registry_source_key:
        raise KpiDefinitionProjectionError(
            'KPI Definition projection target contains a different dependency source key'
        )
    return dependency
