class KpiDefinitionValidationError(ValueError):
    pass
