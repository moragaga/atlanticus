class KpiHistoryContractError(ValueError):
    pass
