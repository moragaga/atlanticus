class BrandingConfigurationValidationError(ValueError):
    pass
