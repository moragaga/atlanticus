class ProfilesDefinitionError(ValueError):
    pass
