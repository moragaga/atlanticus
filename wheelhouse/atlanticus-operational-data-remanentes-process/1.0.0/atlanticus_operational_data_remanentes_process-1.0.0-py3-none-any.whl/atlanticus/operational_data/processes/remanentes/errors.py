class RemanentesProcessConfigurationError(ValueError):
    pass
