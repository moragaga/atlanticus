class MeteodataProcessConfigurationError(ValueError):
    pass
