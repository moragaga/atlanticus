class AdaAccessDefinitionError(ValueError):
    pass
