class KpiRegistryValidationError(ValueError):
    pass
