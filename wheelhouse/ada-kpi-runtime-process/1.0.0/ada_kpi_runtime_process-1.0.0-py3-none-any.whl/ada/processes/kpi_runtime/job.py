from __future__ import annotations

from datetime import datetime

from ada.kpis.core import KpiCatalog, KpiEvaluation, KpiWatermark
from ada.kpis.evaluation import evaluate_kpi, evaluate_over_kpi
from ada.kpis.persistence import KpiEvaluationBatch, KpiPersistence
from ada.processes.kpi_runtime.errors import KpiRuntimeDataError, KpiRuntimeWatermarkError
from ada.processes.kpi_runtime.models import KpiRuntimeIterationResult, KpiRuntimeOutcome
from ada.processes.kpi_runtime.source_state import PiOperationalWatermarkReader
from atlanticus.operational_data.core import DataSource
from atlanticus.operational_data.planner import DataLoadPlan
from atlanticus.operational_data.sources import DataSourceLoader
from atlanticus.runtime import JobRuntimeContext


class KpiRuntimeJob:
    def __init__(
        self,
        *,
        catalog: KpiCatalog,
        plan: DataLoadPlan,
        loader: DataSourceLoader,
        persistence: KpiPersistence,
        source_watermarks: PiOperationalWatermarkReader,
        reprocess_current: bool = False,
    ) -> None:
        if not isinstance(catalog, KpiCatalog):
            raise TypeError('catalog must be a KpiCatalog')
        if not isinstance(plan, DataLoadPlan):
            raise TypeError('plan must be a DataLoadPlan')
        if not isinstance(loader, DataSourceLoader):
            raise TypeError('loader must be a DataSourceLoader')
        if not isinstance(persistence, KpiPersistence):
            raise TypeError('persistence must be a KpiPersistence')
        if not callable(getattr(source_watermarks, 'current', None)):
            raise TypeError('source_watermarks must provide a callable current method')
        if not isinstance(reprocess_current, bool):
            raise TypeError('reprocess_current must be bool')
        self._catalog = catalog
        self._plan = plan
        self._loader = loader
        self._persistence = persistence
        self._source_watermarks = source_watermarks
        self._reprocess_current = reprocess_current

    def run_iteration(self, context: JobRuntimeContext) -> KpiRuntimeIterationResult:
        context.raise_if_cancelled()
        observed = self._source_watermarks.current()
        committed = self._persistence.committed_watermark()
        _record_before(context, observed=observed, committed=committed)
        if observed is None:
            return _empty(
                context,
                reason='source_watermark_missing',
                source_watermark=None,
                committed=committed,
            )
        if committed is not None and observed < committed:
            raise KpiRuntimeWatermarkError(
                'source watermark must not be older than the KPI committed watermark'
            )
        if observed == committed and not self._reprocess_current:
            return _empty(
                context,
                reason='up_to_date',
                source_watermark=observed,
                committed=committed,
            )
        if len(self._catalog) == 0:
            return _empty(
                context,
                reason='no_kpis_configured',
                source_watermark=observed,
                committed=committed,
            )

        reprocess_evaluated_at = (
            _reprocess_evaluated_at(self._persistence, observed)
            if self._reprocess_current and observed == committed
            else {}
        )
        loaded = self._loader.load(plan=self._plan, as_of=observed.timestamp_utc)
        source_traces = {
            DataSource.PI_INTERPOLATED: observed,
            DataSource.PI_RECORDED: observed,
        }
        evaluations: list[KpiEvaluation] = []
        resolved: dict[str, KpiEvaluation] = {}

        for spec in self._catalog.specs:
            evaluation = evaluate_kpi(
                spec=spec,
                context=loaded.context_for(spec.key),
                watermark=observed,
                source_watermarks=source_traces,
                evaluated_at_utc=reprocess_evaluated_at.get(spec.key),
            )
            evaluations.append(evaluation)
            resolved[spec.key] = evaluation

        for spec in self._catalog.over_specs:
            evaluation = evaluate_over_kpi(
                spec=spec,
                dependencies={key: resolved[key] for key in spec.dependencies},
                watermark=observed,
                evaluated_at_utc=reprocess_evaluated_at.get(spec.key),
            )
            evaluations.append(evaluation)
            resolved[spec.key] = evaluation

        batch = KpiEvaluationBatch(watermark=observed, evaluations=tuple(evaluations))
        context.raise_if_cancelled()
        context.assert_lease_current()
        with context.fenced_mutation():
            commit = self._persistence.commit(batch)
        context.mark_iteration_work()
        context.increment_execution_counter('evaluations_committed')
        _record_after(
            context,
            observed=observed,
            before=commit.before,
            after=commit.after,
            write_status=commit.write_status.value,
            evaluation_count=len(evaluations),
        )
        return KpiRuntimeIterationResult(
            outcome=KpiRuntimeOutcome.COMPLETED,
            reason='evaluated',
            source_watermark=observed,
            committed_before=commit.before,
            committed_after=commit.after,
            evaluation_write_status=commit.write_status,
            evaluation_count=len(evaluations),
        )


def _reprocess_evaluated_at(
    persistence: KpiPersistence,
    watermark: KpiWatermark,
) -> dict[str, datetime]:
    batches = persistence.read_committed_after()
    if not batches or batches[-1].watermark != watermark:
        raise KpiRuntimeDataError('KPI committed watermark must have a durable evaluation batch')
    return {evaluation.key: evaluation.evaluated_at_utc for evaluation in batches[-1].evaluations}


def _empty(
    context: JobRuntimeContext,
    *,
    reason: str,
    source_watermark: KpiWatermark | None,
    committed: KpiWatermark | None,
) -> KpiRuntimeIterationResult:
    context.set_iteration_fact('outcome', KpiRuntimeOutcome.EMPTY.value)
    context.set_iteration_fact('reason', reason)
    if committed is not None:
        current = committed.to_text()
        context.set_iteration_fact('kpi_committed_before_utc', current)
        context.set_iteration_fact('kpi_committed_after_utc', current)
    return KpiRuntimeIterationResult(
        outcome=KpiRuntimeOutcome.EMPTY,
        reason=reason,
        source_watermark=source_watermark,
        committed_before=committed,
        committed_after=committed,
    )


def _record_before(
    context: JobRuntimeContext,
    *,
    observed: KpiWatermark | None,
    committed: KpiWatermark | None,
) -> None:
    if observed is not None:
        source = observed.to_text()
        context.set_iteration_fact('pi_observed_watermark_utc', source)
        context.set_execution_fact('pi_observed_watermark_utc', source)
    if committed is not None:
        current = committed.to_text()
        context.set_iteration_fact('kpi_committed_before_utc', current)
        context.set_execution_fact('kpi_committed_watermark_utc', current)


def _record_after(
    context: JobRuntimeContext,
    *,
    observed: KpiWatermark,
    before: KpiWatermark | None,
    after: KpiWatermark,
    write_status: str,
    evaluation_count: int,
) -> None:
    context.set_iteration_fact('outcome', KpiRuntimeOutcome.COMPLETED.value)
    context.set_iteration_fact('reason', 'evaluated')
    context.set_iteration_fact('pi_watermark_utc', observed.to_text())
    if before is not None:
        context.set_iteration_fact('kpi_committed_before_utc', before.to_text())
    context.set_iteration_fact('kpi_committed_after_utc', after.to_text())
    context.set_iteration_fact('evaluation_write_status', write_status)
    context.set_iteration_fact('evaluation_count', evaluation_count)
    context.set_execution_fact('kpi_committed_watermark_utc', after.to_text())
