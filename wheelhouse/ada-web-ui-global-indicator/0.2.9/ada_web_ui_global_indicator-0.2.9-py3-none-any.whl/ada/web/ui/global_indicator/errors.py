class GlobalIndicatorDefinitionError(ValueError):
    pass
